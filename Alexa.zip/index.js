
var request = require("request")

// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.
exports.handler = function (event, context) {
    try {
        console.log("event.session.application.applicationId=" + event.session.application.applicationId);

        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */
         
//     if (event.session.application.applicationId !== "amzn1.echo-sdk-ams.app.05aecccb3-1461-48fb-a008-822ddrt6b516") {
//         context.fail("Invalid Application ID");
//      }

        if (event.session.new) {
            onSessionStarted({requestId: event.request.requestId}, event.session);
        }

        if (event.request.type === "LaunchRequest") {
            onLaunch(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "IntentRequest") {
            onIntent(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "SessionEndedRequest") {
            onSessionEnded(event.request, event.session);
            context.succeed();
        }
    } catch (e) {
        context.fail("Exception: " + e);
    }
};

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    console.log("onSessionStarted requestId=" + sessionStartedRequest.requestId
        + ", sessionId=" + session.sessionId);
    
    // add any session init logic here
}

/**
 * Called when the user invokes the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback) {
    console.log("onLaunch requestId=" + launchRequest.requestId
        + ", sessionId=" + session.sessionId);

    var cardTitle = "Packeru, helps you pack your stuff in a smart way!!"
    var speechOutput = "You can ask me, help me pack !!"
    callback(session.attributes,
        buildSpeechletResponse(cardTitle, speechOutput, "", true));
    //res.say(speechOutput).reprompt(speechOutput).shouldEndSession(false);    
}

/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(intentRequest, session, callback) {
    console.log("onIntent requestId=" + intentRequest.requestId
        + ", sessionId=" + session.sessionId);

    var intent = intentRequest.intent,
        intentName = intentRequest.intent.name;

    // dispatch custom intents to handlers here
    if (intentName == 'FirstIntent') {
        console.log("First Intent");
        handleFirstRequest(intent, session, callback);
    }
    
    if( intentName == 'CheckListIntent'){
        console.log('Checklist Intent');
        handleCheckListRequest(intent,session,callback);
    }
    if(intentName == 'SecondIntent') {
        console.log("Second Intent");
        handleSecondRequest(intent, session, callback);
    }
    
    if(intentName == 'ThirdIntent') {
        console.log("Third Intent");
        handleThirdRequest(intent, session, callback);
    }
    
    if( intentName == 'UpdateIntent'){
        console.log('Update Intent');
        var itemSlot = intent.slots.Items.value;
        session.attributes = {
        
            "updateItem" : itemSlot
        }
        console.log("Item is" + itemSlot)
        handleUpdateRequest(intent,session,callback);
    }
    
    if(intentName == 'OrderAmazonIntent'){
        console.log('Order From Amazon');
        var bookSlot = intent.slots.Items.value;
                session.attributes = {
        
            "orderItem" : bookSlot
        }
        orderFromAmazon(intent,session,callback);
    }
    
    if( intentName == 'CancelIntent'){
        callback(session.attributes,buildSpeechletResponseWithoutCard("Thanks for using Packeru.", "", "true"));
    }
    
    if( intentName == 'RepeatCheckListIntent'){
        console.log('Repeat Check List Intent');
        handleRepeatCheckListRequest(intent,session,callback);
    }
    
    if( intentName == 'BaggageIntent'){
        //handleBaggageIntent(intent,session,callback);
        callback(session.attributes,buildSpeechletResponseWithoutCard("Your carrier Southwest permits 0 check-in bags, and 2 carry-on items, each weighing under 15 kg with dimensions less than 60' by 60' by 60'", "", "false"));
    }
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {
    console.log("onSessionEnded requestId=" + sessionEndedRequest.requestId
        + ", sessionId=" + session.sessionId);

    // Add any cleanup logic here
}


function handleFirstRequest(intent, session, callback) {

    var d = "error"
    getJSON(function(data) {
        if (data != "ERROR") {
            var d = data
    }

     session.attributes = {
        "destination" : d.destination,
        "weather" : d.weather,
        "duration" : d.duration,
        "recommendations": d.recommendations,
        "checklist" : d.checklist
    }
    
    
    callback(session.attributes,buildSpeechletResponseWithoutCard("Okay, I have your trip to " + session.attributes.destination + ".. Do you want me to go through your checklist ?", "", "false"));
    })
        
    }
    
function handleRepeatCheckListRequest(intent, session, callback) {
    
    var d = "error"
    getJSON(function(data) {
        if (data != "ERROR") {
            var d = data
    }

     session.attributes = {
        "destination" : d.destination,
        "weather" : d.weather,
        "duration" : d.duration,
        "recommendations": d.recommendations,
        "checklist" : d.checklist
    }
    console.log('Attributes are set')
    var checklist = session.attributes.checklist;
    var size = checklist.length;
    var output="";
    console.log('error here b4 length' + size)
    if(size < 1){
        
        output = "Seems like your checklist are all good and read to go. Do you need more assistance ?"
        callback(session.attributes,
        buildSpeechletResponseWithoutCard( output , "", "false"));
    }else{
        console.log('error here')
        for( var i = 0; i < size ; i++){
            output = output + "," + checklist[i];
        }
        
        callback(session.attributes,
        buildSpeechletResponseWithoutCard("Seems like you have missed quite a few items from your checklist !!! Dont forget to take " + output + ".. Anything else?", "", "false"));
    }
    });
    

}

function handleCheckListRequest(intent,session,callback){
    var checklist = session.attributes.checklist;
    var output="";
    
    if(checklist.length < 1){
        output = "Seems like your checklist are all good and ready to go. Do you need more assistance ?"
        callback(session.attributes,
        buildSpeechletResponseWithoutCard( output , "", "false"));
    }else{
        for( var i = 0; i < checklist.length; i++){
            output = output + "," + checklist[i];
        }
        
        callback(session.attributes,
        buildSpeechletResponseWithoutCard("Seems like you have missed quite a few items from your checklist still!!! Dont forget to take " + output + ".. Anything else?", "", "false"));
    }
    
}

function handleSecondRequest(intent, session, callback) {
    var recommendations = session.attributes.recommendations;
    callback(session.attributes,
        buildSpeechletResponseWithoutCard("For the duration of your trip, weather forecasts indicate that it will be " + session.attributes.weather +" for "+ session.attributes.duration + " days. I would recommend packing "+recommendations[0], "", "false"));
}

function handleThirdRequest(intent, session, callback) {
    var recommendations = session.attributes.recommendations;
    var output="";
    
    if(recommendations.length < 2){
        output = "Sorry, I have no more recommendations to give you"
        
        callback(session.attributes,
        buildSpeechletResponseWithoutCard( output , "", "false"));
    }else{
        for( var i = 1; i < recommendations.length; i++){
            output = output + "," + recommendations[i];
        }
        
        callback(session.attributes,
        buildSpeechletResponseWithoutCard("I would also recommend packing " + output, "", "false"));
    }
}


function handleUpdateRequest(intent, session, callback) {
    var d = "error"
    sendJSON(session,function(data) {
        if (data != "ERROR") {
            var d = data
    }   
    callback(session.attributes,buildSpeechletResponseWithoutCard( "I have updated the checklist for you. Anything else ?","", "false"));
    })
}

function orderFromAmazon(intent, session, callback){
    
    callback(session.attributes,buildSpeechletResponseWithoutCard( "I have checked the amazon catalog for the item "+ session.attributes.orderItem + ".. and I Cant book it for you since payment method isnt integrated.","", "false"));
}

// ------- Helper functions to build responses -------

function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: output
        },
        card: {
            type: "Simple",
            title: title,
            content: output
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: false
    };
}

function buildSpeechletResponseWithoutCard(output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: output
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: shouldEndSession
    };
}

function buildResponse(sessionAttributes, speechletResponse) {
    return {
        version: "1.0",
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    };
}

/*
To hit an external api to get the response
*/
function url() {
    return "http://ec2-54-245-153-226.us-west-2.compute.amazonaws.com/test"
}

function url1(){
    return "http://ec2-54-245-153-226.us-west-2.compute.amazonaws.com/get_checklist_alexa"
}

function url2(){
    
    return "http://ec2-54-245-153-226.us-west-2.compute.amazonaws.com/update_checklist"
}

function getJSON(callback) {

    request.get(url1(), function(error, response, body) {
        var d = JSON.parse(body)
        var destination = d.destination
        var weather = d.weather
        var duration = d.duration
        var checklist = d.checklist
        var recommendations = d.recommendations
            /*
                myArray.forEach(function(value){
                    console.log(value);
            });
            */
            console.log("Result is :" + d.checklist[0])
            callback(d)

    })
}

function sendJSON(session,callback){
    
 request.post(
    url2(),
     { json: { "item": session.attributes.updateItem } },
    function (error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log(body)
            var d = "good"
            callback(d)
        }else{
            
            var d = "ERROR"
            callback(d)
        }
    }
);
    
}